library(testthat)
library(bit64)

test_check("bit64")
