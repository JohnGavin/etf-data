#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @import scales grid gtable rlang vctrs
#' @importFrom lifecycle deprecated
#' @importFrom stats setNames
#' @importFrom utils head tail
## usethis namespace: end
NULL
