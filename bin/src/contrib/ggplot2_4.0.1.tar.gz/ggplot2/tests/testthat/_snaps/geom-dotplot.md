# NA's result in warning from stat_bindot

    Removed 2 rows containing missing values or values outside the scale range (`stat_bindot()`).

# weight aesthetic is checked

    Computation failed in `stat_bindot()`.
    Caused by error in `compute_group()`:
    ! `weight` must be nonnegative integers, not a double vector.

---

    Computation failed in `stat_bindot()`.
    Caused by error in `compute_group()`:
    ! `weight` must be nonnegative integers, not a double vector.

# geom_dotplot draws correctly

    Removed 2 rows containing missing values or values outside the scale range (`stat_bindot()`).

---

    Removed 2 rows containing missing values or values outside the scale range (`stat_bindot()`).

