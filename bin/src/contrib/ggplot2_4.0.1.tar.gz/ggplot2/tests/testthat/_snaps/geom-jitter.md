# geom_jitter() throws relevant errors

    Both `position` and `width`/`height` were supplied.
    i Choose a single approach to alter the position.

