# stat_density2d can produce contour and raster data

    Problem while computing stat.
    i Error occurred in the 1st layer.
    Caused by error in `compute_layer()`:
    ! `contour_var` must be one of "density", "ndensity", or "count", not "abcd".

# stat_density_2d handles faulty bandwidth

    Computation failed in `stat_density2d()`.
    Caused by error in `precompute_2d_bw()`:
    ! The bandwidth argument `h` must contain numbers larger than 0.
    i Please set the `h` argument to stricly positive numbers manually.

