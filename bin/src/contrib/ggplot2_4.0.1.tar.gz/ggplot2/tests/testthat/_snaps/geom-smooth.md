# geom_smooth() works when one group fails

    span too small.   fewer data values than degrees of freedom.

