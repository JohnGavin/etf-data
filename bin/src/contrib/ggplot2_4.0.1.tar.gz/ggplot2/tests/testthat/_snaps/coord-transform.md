# warnings are generated when coord_transform() results in new infinite values

    Transformation introduced infinite values in y-axis

---

    Transformation introduced infinite values in x-axis

# coord_transform() throws error when limits are badly specified

    `xlim` must be a vector, not a <ScaleContinuousPosition> object.

---

    `ylim` must be a vector of length 2, not length 3.

