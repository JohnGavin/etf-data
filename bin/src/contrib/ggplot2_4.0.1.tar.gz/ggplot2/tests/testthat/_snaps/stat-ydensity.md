# calc_bw() requires at least two values and correct method

    `x` must contain at least 2 elements to select a bandwidth automatically.

---

    `test` is not a valid bandwidth rule.

# `drop = FALSE` preserves groups with 1 observations

    Groups with fewer than two datapoints have been dropped.
    i Set `drop = FALSE` to consider such groups for position adjustment purposes.

---

    Cannot compute density for groups with fewer than two datapoints.

