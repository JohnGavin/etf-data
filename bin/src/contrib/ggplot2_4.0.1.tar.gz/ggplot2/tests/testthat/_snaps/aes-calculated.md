# staged aesthetics warn appropriately for duplicated names

    Duplicated aesthetics after name standardisation: colour

---

    Duplicated aesthetics after name standardisation: colour

# calculated aesthetics throw warnings when lengths mismatch

    Failed to apply `after_stat()` for the following aesthetic: colour.

---

    Failed to apply `after_scale()` for the following aesthetic: colour.

# A deprecated warning is issued when stat(var) or ..var.. is used

    `stat(foo)` was deprecated in ggplot2 3.4.0.
    i Please use `after_stat(foo)` instead.

---

    The dot-dot notation (`..bar..`) was deprecated in ggplot2 3.4.0.
    i Please use `after_stat(bar)` instead.

