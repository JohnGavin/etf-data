# coord map throws error when limits are badly specified

    `xlim` must be a vector, not a <ScaleContinuousPosition> object.

---

    `ylim` must be a vector of length 2, not length 3.

# coord_map throws informative warning about guides

    `coord_map()` cannot render guide for the aesthetic: x.

