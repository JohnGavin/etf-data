# geom_rect can derive corners

    Code
      GeomRect$setup_data(test, NULL)
    Condition
      Error in `resolve_rect()`:
      ! `geom_rect()` requires two of the following aesthetics: xmin, xmax, x, or width.
      i Currently, x is present.

