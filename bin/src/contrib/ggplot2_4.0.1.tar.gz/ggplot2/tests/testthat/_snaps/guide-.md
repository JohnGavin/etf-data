# dots are checked when making guides

    Ignoring unknown argument to `guide_axis()`: `foo`.

---

    Arguments in `...` must be used.
    x Problematic argument:
    * foo = "bar"
    i Did you misspell an argument name?

