# a warning is generated when guides are drawn at a location that doesn't make sense

    Position guide is perpendicular to the intended axis.
    i Did you mean to specify a different guide `position`?

# a warning is generated when more than one position guide is drawn at a location

    `guide_axis()`: Discarding guide on merge.
    i Do you have more than one guide with the same `position`?

# Using non-position guides for position scales results in an informative error

    `guide_legend()` cannot be used for x, xmin, xmax, or xend.
    i Use any non position aesthetic instead.

# guide_axis_logticks calculates appropriate ticks

    The `prescale.base` argument will override the scale's log-10 transformation in log-tick positioning.

