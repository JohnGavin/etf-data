# qplot() only work with character geom

    `geom` must be a character vector, not a <GeomLinerange> object.

