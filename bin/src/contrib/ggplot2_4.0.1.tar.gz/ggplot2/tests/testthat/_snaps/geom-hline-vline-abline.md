# warnings are thrown when parameters cause mapping and data to be ignored

    `geom_vline()`: Ignoring `mapping` because `xintercept` was provided.

---

    `geom_vline()`: Ignoring `data` because `xintercept` was provided.

---

    `geom_hline()`: Ignoring `mapping` because `yintercept` was provided.

---

    `geom_hline()`: Ignoring `data` because `yintercept` was provided.

---

    `geom_abline()`: Ignoring `mapping` because `slope` and/or `intercept` were provided.

---

    `geom_abline()`: Ignoring `mapping` because `slope` and/or `intercept` were provided.

---

    `geom_abline()`: Ignoring `data` because `slope` and/or `intercept` were provided.

---

    `geom_abline()`: Ignoring `data` because `slope` and/or `intercept` were provided.

