# geom_label() throws meaningful errors

    Ignoring unknown parameters: `nudge_x`

---

    `label` must be of length 1.

