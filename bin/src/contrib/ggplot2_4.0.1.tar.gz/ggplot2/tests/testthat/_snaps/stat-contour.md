# a warning is issued when there is more than one z per x+y

    Contour data has duplicated x, y coordinates.
    i 1 duplicated row have been dropped.

# contouring sparse data results in a warning

    `stat_contour()`: Zero contours were generated

# stat_contour() removes duplicated coordinates

    Contour data has duplicated x, y coordinates.
    i 4 duplicated rows have been dropped.

