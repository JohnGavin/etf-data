# binwidth is respected

    Computation failed in `stat_bin2d()`.
    Caused by error in `compute_bins()`:
    ! `binwidth` must be a number, not a double vector.

---

    Computation failed in `stat_bin2d()`.
    Caused by error in `compute_bins()`:
    ! `boundary` must be a number or `NULL`, not a double vector.

