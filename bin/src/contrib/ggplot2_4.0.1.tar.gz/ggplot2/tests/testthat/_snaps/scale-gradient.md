# midpoints are transformed

    log-10 transformation introduced infinite values in `midpoint`.

