#ifndef TZDB_PTZ_H
#define TZDB_PTZ_H

#include <tzdb/defines.h>
#include <date/ptz.h>

#endif
