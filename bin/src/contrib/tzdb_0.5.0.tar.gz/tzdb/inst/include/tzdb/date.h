#ifndef TZDB_DATE_H
#define TZDB_DATE_H

#include <tzdb/defines.h>
#include <date/date.h>

#endif
