test_that("can call `tzdb_initialize()`", {
  expect_identical(tzdb_initialize(), NULL)
})
