# get_etf_universe returns expected structure

    Code
      head(uni)
    Output
      # A tibble: 6 x 4
        ticker name                                  isin         currency
        <chr>  <chr>                                 <chr>        <chr>   
      1 VUSA.L Vanguard S&P 500 UCITS ETF            IE00B3XXRP09 GBP     
      2 CSPX.L iShares Core S&P 500 UCITS ETF        IE00B5BMR087 GBP     
      3 INRG.L iShares Global Clean Energy UCITS ETF IE00B1XNHC34 GBP     
      4 EQQQ.L Invesco EQQQ Nasdaq-100 UCITS ETF     IE0032077012 GBP     
      5 VWRL.L Vanguard FTSE All-World UCITS ETF     IE00B3RBWM25 GBP     
      6 ISF.L  iShares Core FTSE 100 UCITS ETF       IE0005042456 GBP     

