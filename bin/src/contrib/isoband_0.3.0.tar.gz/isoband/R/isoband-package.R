#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @useDynLib isoband, .registration = TRUE
#' @importFrom utils modifyList
#' @import grid rlang
## usethis namespace: end
NULL
