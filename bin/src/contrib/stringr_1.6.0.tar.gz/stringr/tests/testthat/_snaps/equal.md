# vectorised using TRR

    Code
      str_equal(letters[1:3], c("a", "b"))
    Condition
      Error in `str_equal()`:
      ! Can't recycle `x` (size 3) to match `y` (size 2).

