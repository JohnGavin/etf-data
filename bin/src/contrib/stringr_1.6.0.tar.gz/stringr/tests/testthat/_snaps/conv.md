# check encoding argument

    Code
      str_conv("A", c("ISO-8859-1", "ISO-8859-2"))
    Condition
      Error in `str_conv()`:
      ! `encoding` must be a single string, not a character vector.

