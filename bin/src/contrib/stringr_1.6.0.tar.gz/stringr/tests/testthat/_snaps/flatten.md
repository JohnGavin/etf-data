# collapse must be single string

    Code
      str_flatten("A", c("a", "b"))
    Condition
      Error in `str_flatten()`:
      ! `collapse` must be a single string, not a character vector.

