# modify list adds, removes, and overrides

    Code
      modify_list(x, a = 1, 2)
    Condition
      Error:
      ! All components of `...` must be named.

# progress bar suppressed in tests

    Code
      sys_sleep(0.1, "in test")
    Message
      > Waiting 0.1s in test

