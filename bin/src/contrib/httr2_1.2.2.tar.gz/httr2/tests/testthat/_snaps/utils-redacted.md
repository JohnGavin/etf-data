# sentinel displays nicely

    Code
      x
    Output
      <REDACTED>
    Code
      format(x)
    Output
      [1] "<REDACTED>"
    Code
      str(x)
    Output
       <REDACTED>

