library(testthat)
library(munsell)
test_check("munsell")