## usethis namespace: start
#' @importFrom utils globalVariables
#' @importFrom utils head str hasName
#' @useDynLib S7, .registration = TRUE
## usethis namespace: end
NULL
