# can register convert methods

    Code
      convert(obj, to = class_double)
    Condition
      Error:
      ! Can't find method for generic `convert()` with dispatch classes:
      - from: <converttest>
      - to  : <double>

