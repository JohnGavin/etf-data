# can test and print

    Code
      print(class_missing)
    Output
      <S7_missing>
    Code
      print(class_any)
    Output
      <S7_any>
    Code
      str(list(m = class_missing, a = class_any))
    Output
      List of 2
       $ m: <S7_missing>
       $ a: <S7_any>

