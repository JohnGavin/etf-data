## revdepcheck results

We checked 1344 reverse dependencies (1330 from CRAN + 14 from Bioconductor), comparing R CMD check results across CRAN and dev versions of this package.

 * We saw 0 new problems
 * We failed to check 8 packages

Issues with CRAN packages are summarised below.

### Failed to check

* FAfA         (NA)
* fio          (NA)
* lavaan.shiny (NA)
* loon.shiny   (NA)
* RSP          (NA)
* rstanarm     (NA)
* sphereML     (NA)
* TestAnaAPP   (NA)
