# Revdeps

## Failed to check (22)

|package              |version |error |warning |note |
|:--------------------|:-------|:-----|:-------|:----|
|bigPint              |?       |      |        |     |
|bioCancer            |?       |      |        |     |
|EBImage              |?       |      |        |     |
|FAfA                 |0.3     |1     |        |     |
|fio                  |0.1.6   |1     |        |     |
|GeneNetworkBuilder   |?       |      |        |     |
|gradientPickerD3     |?       |      |        |     |
|InterCellar          |?       |      |        |     |
|LACE                 |?       |      |        |     |
|lavaan.shiny         |1.2     |1     |        |     |
|LDABiplots           |?       |      |        |     |
|LDAShiny             |?       |      |        |     |
|loon.shiny           |?       |      |        |     |
|MatrixQCvis          |?       |      |        |     |
|metricsgraphics      |?       |      |        |     |
|modchart             |?       |      |        |     |
|omicsViewer          |?       |      |        |     |
|RSP                  |0.4     |1     |        |     |
|rstanarm             |2.32.1  |1     |        |     |
|sphereML             |0.1.1   |1     |        |     |
|StatTeacherAssistant |?       |      |        |     |
|TestAnaAPP           |1.1.2   |1     |        |     |
