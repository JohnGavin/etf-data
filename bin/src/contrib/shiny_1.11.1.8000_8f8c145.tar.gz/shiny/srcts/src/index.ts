import { init } from "./initialize";
export { Shiny, type ShinyClass } from "./initialize";

init();
