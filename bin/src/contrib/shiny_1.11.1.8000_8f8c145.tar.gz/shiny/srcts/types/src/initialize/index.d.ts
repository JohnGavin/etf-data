import { ShinyClass } from "../shiny";
declare let Shiny: ShinyClass;
declare function init(): void;
export { init, Shiny, type ShinyClass };
