declare function showReconnectDialog(delay: number): Promise<void>;
declare function hideReconnectDialog(): void;
export { showReconnectDialog, hideReconnectDialog };
