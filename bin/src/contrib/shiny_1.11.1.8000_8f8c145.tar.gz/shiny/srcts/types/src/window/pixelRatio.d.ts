declare function windowDevicePixelRatio(): number;
export { windowDevicePixelRatio };
