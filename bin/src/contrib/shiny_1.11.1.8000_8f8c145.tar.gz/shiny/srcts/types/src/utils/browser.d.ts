declare function setIsQt(isQt: boolean): void;
declare function setIsIE(isIE: boolean): void;
declare function setIEVersion(versionIE_: number): void;
declare function isQt(): boolean;
declare function isIE(): boolean;
declare function IEVersion(): number;
export { isQt, isIE, IEVersion, setIsQt, setIsIE, setIEVersion };
